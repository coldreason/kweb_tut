import 'dart:ui';

const Color recipleOrange = Color(0xffF35001);
const Color recipleGreyBlue = Color(0xff14123D);

const Color grey = Color(0xff707070);
const Color transparentGrey = Color(0xffF0EEEB);

const Color selectedEarthColor = Color(0xffD06B4C);

const Color naverGreen = Color(0xff03c75a);
const Color kakaoYellow = Color(0xfffee500);
const Color kakaoFontBlack = Color(0xff191919);
const Color googleFontGrey = Color(0x8a000000);